# primeicons
Font Icon Library for Prime UI Libraries